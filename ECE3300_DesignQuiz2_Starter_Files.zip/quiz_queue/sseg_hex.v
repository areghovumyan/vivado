// sseg_hex.v -- hex digit to 7-segment pattern, ACTIVE LOW (Lab, Step 7; Quiz 1)
module sseg_hex (
    input      [3:0] hex,
    output reg [6:0] seg        // {g,f,e,d,c,b,a}, 0 = segment ON
);
    always @(*) begin
        case (hex)              //  gfedcba
            4'h0: seg = 7'b1000000;
            4'h1: seg = 7'b1111001;
            4'h2: seg = 7'b0100100;
            4'h3: seg = 7'b0110000;
            4'h4: seg = 7'b0011001;
            4'h5: seg = 7'b0010010;
            4'h6: seg = 7'b0000010;
            4'h7: seg = 7'b1111000;
            4'h8: seg = 7'b0000000;
            4'h9: seg = 7'b0010000;
            4'hA: seg = 7'b0001000;
            4'hB: seg = 7'b0000011;
            4'hC: seg = 7'b1000110;
            4'hD: seg = 7'b0100001;
            4'hE: seg = 7'b0000110;
            default: seg = 7'b0001110;  // F
        endcase
    end
endmodule
